import { AuthPage } from "@refinedev/antd";

export const ForgotPassword = () => {
  return <AuthPage type="forgotPassword" />;
};
