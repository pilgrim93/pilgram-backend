import { AuthPage } from "@refinedev/antd";

export const Register = () => {
  return <AuthPage type="register" />;
};
